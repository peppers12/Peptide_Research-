# Peptide Research Guide - GitHub Pages

This folder is a static copy of the current Peptide Research Guide and is ready for free GitHub Pages hosting.

## Publish with GitHub Pages

1. Create a new GitHub repository, for example: `peptide-research`.
2. Upload every file in this folder to the repository root.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then press **Save**.
6. After GitHub publishes it, open the Pages URL in Safari on your iPhone.
7. Tap **Share → Add to Home Screen**.

The included `apple-touch-icon.png` is public, so iOS can fetch the Peptide Research icon correctly.

## Files

- `index.html` – app shell
- `styles.css` – current dark navy/cyan theme
- `app.js` – 110-compound guide and current ION links
- `research-logo.jpg` – page logo
- `apple-touch-icon.png` – iPhone Home Screen icon
- `icon-512.png` – browser/site icon
