const compounds=["5-Amino-1MQ","ACE-031","Adamax 1032","Adipotide","Afamelanotide","AHK-Cu","AICAR","Amycretin","AOD-9604","Astaxanthin Complex","B12","B12 (Methylated)","BPC-157","Bremelanotide","Bronchogen","Cagrilintide","Cardiogen","Cartalax","Centella Asiatica Complex","Cerebro Protein","Cerebrolysin","Chonluten","Cibinetide","CJC-1295 no DAC","CJC-1295 no DAC / Ipamorelin","CJC-1295 with DAC","Crystagen","Dihexa","DSIP","Dulaglutide","Elora","Eloralintide","Epitalon","Exenatide","Follistatin-344","FOXO4-DRI","GHK Complex","GHK-Cu","GHRP-2","GHRP-6","GLOW","Glutathione","Gonadorelin","HCG","Hexarelin","HGH","HMG","Humanin","Ibutamoren","IGF-1 DES","IGF-1 LR3","Ipamorelin","Kisspeptin","KLOW","KPV","L-Carnitine","LIPO-C + B12 (Methylated)","Lipo-C Burn Blend","Liraglutide","LL-37","Lonapegsomatropin-tcgd","Matrixyl","Mazdutide","Melanotan II","Methylene blue","MGF","MOTS-c","N-Acetyl Selank Amidate","N-Acetyl Semax Amidate","NAD+","Ovagen","Oxytocin","P21","PDA","PDRN","PDRN Collagen Complex","PE-22-28","PEG-MGF","Pemvidutide","Pinealon","PNC-27","Retatrutide","Selank","Selank (N-Acetyl)","Semaglutide","Semax","Semax (N-Acetyl)","Semax/Selank","Sermorelin","SLU-PP-332","Snap-8","Somapacitan-beco","Somatrogon-ghla","SS-31","Survodutide","TB-500","Tesa/Ipamo","Tesamorelin","Tesofensine","Testosterone cypionate","Testosterone enanthate","Testosterone propionate","Thymalin","Thymosin alpha-1","Thymosin beta-4","Tirzepatide","Triptorelin","Vesugen","Vilon","VIP"];
const approved=new Set(["Afamelanotide","Bremelanotide","Dulaglutide","Exenatide","Liraglutide","Lonapegsomatropin-tcgd","Semaglutide","Somapacitan-beco","Somatrogon-ghla","Tesamorelin","Tirzepatide","Triptorelin"]);const investigational=new Set(["Amycretin","Cagrilintide","Cibinetide","Eloralintide","Mazdutide","Pemvidutide","Retatrutide","Survodutide"]);const hormone=/^(HCG|HMG|HGH|Gonadorelin|Oxytocin|Testosterone )/;const blend=/(Complex|Blend|GLOW|KLOW|\/)/;
const uses={
"5-Amino-1MQ":"Studied as an NNMT inhibitor; online communities discuss it mainly for body-composition and metabolic research.","ACE-031":"Myostatin/activin-pathway research aimed at increasing muscle mass and strength.","Adipotide":"Experimental fat-loss research targeting blood vessels associated with adipose tissue.","Afamelanotide":"Melanocortin analog used clinically for erythropoietic protoporphyria; also discussed for pigmentation.","AHK-Cu":"Copper-binding peptide discussed for skin, hair and tissue-repair research.","AICAR":"AMPK-pathway research related to cellular energy use, endurance and metabolism.","Amycretin":"Investigational amylin/GLP-1 related obesity and metabolic therapy.","AOD-9604":"Growth-hormone fragment researched for fat metabolism without the full growth effects of HGH.","BPC-157":"Widely discussed experimental peptide for tendon, gut and soft-tissue healing; human evidence remains limited.","Bremelanotide":"Melanocortin receptor agonist used for hypoactive sexual desire disorder and discussed for libido.","Cagrilintide":"Long-acting amylin analog investigated for appetite suppression and weight management.","Cerebrolysin":"Peptide/amino-acid mixture used in some countries for neurologic indications; communities discuss cognition and recovery.","Cibinetide":"ARA-290-derived peptide studied for tissue protection, inflammation and neuropathic pain.","CJC-1295 no DAC":"Growth-hormone-releasing hormone analog used in research to increase pulsatile GH signaling.","CJC-1295 no DAC / Ipamorelin":"Combination discussed for growth-hormone pulse stimulation and recovery/body-composition goals.","CJC-1295 with DAC":"Longer-acting GHRH analog researched for sustained GH/IGF-1 elevation.","Dihexa":"Experimental neurotrophic compound discussed for memory and cognition research.","DSIP":"Delta sleep-inducing peptide discussed for sleep and stress research; evidence is limited.","Dulaglutide":"Approved GLP-1 medicine for type 2 diabetes; also reduces appetite and body weight.","Eloralintide":"Investigational amylin-receptor agonist being studied for obesity and metabolic disease.","Epitalon":"Synthetic tetrapeptide discussed in longevity research, circadian biology and cellular aging.","Exenatide":"Approved GLP-1 medicine for type 2 diabetes with appetite and weight effects.","Follistatin-344":"Experimental myostatin-pathway research focused on muscle growth.","FOXO4-DRI":"Experimental senolytic peptide intended to target senescent cells in preclinical aging research.","GHK-Cu":"Copper peptide researched for wound healing, skin remodeling and hair-related applications.","GHRP-2":"Growth-hormone secretagogue researched for GH release.","GHRP-6":"Growth-hormone secretagogue known for GH release and often increased appetite.","Glutathione":"Endogenous antioxidant used and studied for oxidative stress and redox support.","Gonadorelin":"GnRH analog used diagnostically/therapeutically in selected settings and discussed for reproductive-axis stimulation.","HCG":"Hormone medication used for fertility and selected endocrine indications; also discussed in testosterone/fertility communities.","Hexarelin":"Potent growth-hormone secretagogue researched for GH release.","HGH":"Human growth hormone used medically for specific deficiency syndromes; communities also discuss body composition and recovery.","HMG":"Gonadotropin medication used in fertility treatment to provide FSH/LH activity.","Humanin":"Mitochondria-derived peptide investigated for cellular stress resistance and aging biology.","Ibutamoren":"Oral ghrelin-receptor agonist researched for increasing GH/IGF-1 and lean mass.","IGF-1 DES":"Short IGF-1 variant researched for local anabolic signaling.","IGF-1 LR3":"Long-acting IGF-1 analog researched for anabolic and growth signaling.","Ipamorelin":"Selective growth-hormone secretagogue discussed for GH release with less appetite/cortisol effect than older GHRPs.","Kisspeptin":"Neuropeptide regulating reproductive hormones; researched for fertility and gonadal-axis signaling.","KPV":"Alpha-MSH fragment researched for anti-inflammatory effects, especially skin and gut models.","L-Carnitine":"Nutrient involved in fatty-acid transport; used for deficiency and discussed for exercise/metabolic support.","Liraglutide":"Approved GLP-1 medicine for diabetes and chronic weight management.","LL-37":"Human antimicrobial peptide researched in innate immunity, wound biology and infection models.","Mazdutide":"Investigational GLP-1/glucagon receptor agonist for obesity and metabolic disease.","Melanotan II":"Unapproved melanocortin analog discussed for tanning and sexual effects; safety concerns exist.","Methylene blue":"Drug/dye with established medical uses at controlled doses and experimental discussion around mitochondrial function and cognition.","MGF":"Mechano growth factor variant of IGF-1 researched in muscle-repair signaling.","MOTS-c":"Mitochondrial-derived peptide investigated for metabolic signaling, exercise adaptation and healthy aging.","NAD+":"Central cellular redox cofactor; supplementation approaches are discussed for energy metabolism and aging research.","Oxytocin":"Endogenous peptide hormone used medically in obstetrics; also studied for social behavior and neuroendocrine effects.","PDRN":"DNA-derived mixture studied for tissue repair, wound healing and regenerative dermatology.","PEG-MGF":"Pegylated MGF analog researched for longer-lasting muscle-repair signaling.","Pemvidutide":"Investigational GLP-1/glucagon agonist studied for obesity and metabolic liver disease.","Retatrutide":"Investigational GIP/GLP-1/glucagon triple agonist being studied for obesity and metabolic disease.","Selank":"Experimental anxiolytic peptide discussed for anxiety, stress and cognition.","Semaglutide":"Approved GLP-1 medicine for diabetes and chronic weight management.","Semax":"Experimental neuroactive peptide discussed for cognition and neurologic research.","Sermorelin":"GHRH analog used historically to stimulate endogenous growth-hormone secretion.","SLU-PP-332":"Preclinical ERR agonist often called an exercise-mimetic compound; no established human use.","SS-31":"Elamipretide; mitochondria-targeted peptide studied for mitochondrial and cardiometabolic disorders.","Survodutide":"Investigational GLP-1/glucagon agonist studied for obesity and steatohepatitis.","TB-500":"Synthetic thymosin-beta-4-related research product discussed for soft-tissue repair and recovery.","Tesamorelin":"Approved GHRH analog for excess abdominal fat in adults with HIV-associated lipodystrophy.","Tesofensine":"Monoamine reuptake inhibitor investigated for obesity; not a peptide despite appearing in the tracker catalog.","Thymosin alpha-1":"Immune-modulating peptide studied and used in some countries for immune-related indications.","Thymosin beta-4":"Endogenous peptide studied for tissue repair, migration and wound healing.","Tirzepatide":"Approved GIP/GLP-1 medicine for type 2 diabetes and chronic weight management.","VIP":"Vasoactive intestinal peptide involved in vascular, pulmonary, immune and gastrointestinal signaling."};
function status(n){if(approved.has(n))return['Approved','approved'];if(investigational.has(n))return['Investigational','investigational'];if(hormone.test(n))return['Hormone / medication','hormone'];if(blend.test(n))return['Blend','blend'];return['Research','research']}
function fallback(n){if(/Pinealon|Vilon|Vesugen|Thymalin|Bronchogen|Cardiogen|Cartalax|Chonluten|Crystagen|Ovagen/.test(n))return'Bioregulatory peptide discussed in longevity-oriented communities for organ- or tissue-specific support; published human evidence varies by compound.';if(/Selank|Semax|P21|PE-22-28|Adamax/.test(n))return'Experimental neuroactive compound discussed for cognition, mood, stress or neurologic research.';if(/B12|Astaxanthin|Centella|Glutathione|NAD/.test(n))return'Non-peptide or mixed research/support compound included in the Tracker catalog and commonly discussed for metabolic, antioxidant or wellness applications.';return'Experimental or research compound included in the Peptide Tracker catalog. Human evidence, legal status and formulation quality vary substantially.'}
function community(n){if(["Semaglutide","Tirzepatide","Liraglutide","Dulaglutide","Exenatide","Bremelanotide","Tesamorelin"].includes(n))return'Reddit discussions commonly compare prescribed titration experiences, side effects, timing and adherence. Use the Reddit link below for first-hand reports, but follow the approved label and prescriber instructions for clinical use.';if(investigational.has(n))return'Reddit users discuss self-directed schedules and dose changes, but these reports are not standardized clinical guidance. Use the Reddit link to review recurring patterns and adverse-effect reports alongside trial protocols.';if(hormone.test(n)||/IGF|HGH|GHRP|CJC|Ipamorelin|Sermorelin|Hexarelin/.test(n))return'Community dosing varies widely and can materially alter hormone levels. The guide links directly to Reddit discussion rather than converting anecdotes into a personalized protocol.';return'Reddit reports often describe route, frequency and amount, but quality and consistency vary. Open the Reddit search below to compare multiple reports before drawing conclusions.'}
function evidence(n){if(approved.has(n))return'Established human clinical evidence exists for specific approved indications. Off-label/community uses may have different evidence.';if(investigational.has(n))return'Human clinical trials exist or are ongoing, but the compound is not broadly approved for routine clinical use.';if(/BPC-157|TB-500|FOXO4|SLU-PP|Dihexa|Adipotide|Follistatin|PNC-27/.test(n))return'Evidence is primarily preclinical or early-stage; high-quality human safety/efficacy data are limited.';return'Published evidence ranges from preclinical work to small human studies depending on the compound. Check PubMed before relying on community claims.'}
function safety(n){if(/GLP|Semaglutide|Tirzepatide|Retatrutide|Liraglutide|Dulaglutide|Exenatide|Cagrilintide|Amycretin|Mazdutide|Pemvidutide|Survodutide|Eloralintide/.test(n))return['GI effects such as nausea, vomiting, constipation or diarrhea are commonly discussed.','Rapid appetite/weight changes can affect hydration, nutrition and medication needs.','Investigational products add uncertainty around purity, dosing accuracy and long-term safety.'];if(hormone.test(n)||/IGF|HGH|GHRP|CJC|Ipamorelin|Sermorelin|Hexarelin/.test(n))return['Can alter endocrine markers and downstream hormone levels.','Monitoring may be important because effects can extend beyond the intended target.','Product quality and dosing accuracy are major concerns outside regulated pharmacy channels.'];return['Human safety data may be incomplete.','Online anecdotes cannot establish safety or effectiveness.','Verify identity, regulatory status and primary literature before acting on claims.']}
const ionLinks={"5-Amino-1MQ":"https://ionpeptide.com/product/5a1mq/","Adamax 1032":"https://ionpeptide.com/product/adamax-1032-10mg/","AHK-Cu":"https://ionpeptide.com/product/ahkc/","AICAR":"https://ionpeptide.com/product/ar50/","B12":"https://ionpeptide.com/product/b1210/","B12 (Methylated)":"https://ionpeptide.com/product/b12m10/","Bronchogen":"https://ionpeptide.com/product/bron20/","Cagrilintide":"https://ionpeptide.com/product/cag/","Cardiogen":"https://ionpeptide.com/product/cdgn/","Cartalax":"https://ionpeptide.com/product/cart20/","Cerebro Protein":"https://ionpeptide.com/product/cbp60/","CJC-1295 no DAC":"https://ionpeptide.com/product/cjcnd/","CJC-1295 no DAC / Ipamorelin":"https://ionpeptide.com/product/cjcip10nd/","CJC-1295 with DAC":"https://ionpeptide.com/product/cjcd5/","Crystagen":"https://ionpeptide.com/product/crystagen-20mg/","DSIP":"https://ionpeptide.com/product/dsip/","Elora":"https://ionpeptide.com/product/elora-10mg/","Epitalon":"https://ionpeptide.com/product/epi/","FOXO4-DRI":"https://ionpeptide.com/product/fdri10/","GHRP-2":"https://ionpeptide.com/product/ghrp25/","GHRP-6":"https://ionpeptide.com/product/ghp65/","GLOW":"https://ionpeptide.com/product/glow70/","Glutathione":"https://ionpeptide.com/product/glu/","HCG":"https://ionpeptide.com/product/hcg/","HMG":"https://ionpeptide.com/product/hmg/","IGF-1 LR3":"https://ionpeptide.com/product/iglr1/","Ipamorelin":"https://ionpeptide.com/product/ipamo/","Kisspeptin":"https://ionpeptide.com/product/ksptn/","KLOW":"https://ionpeptide.com/product/klow80/","KPV":"https://ionpeptide.com/product/kpv10/","L-Carnitine":"https://ionpeptide.com/product/lc5000/","LIPO-C + B12 (Methylated)":"https://ionpeptide.com/product/lcb12m10/","Lipo-C Burn Blend":"https://ionpeptide.com/product/lcb526/","LL-37":"https://ionpeptide.com/product/ll375/","Matrixyl":"https://ionpeptide.com/product/mtx10/","Melanotan II":"https://ionpeptide.com/product/mlt2/","MOTS-c":"https://ionpeptide.com/product/mtsc/","NAD+":"https://ionpeptide.com/product/nadp/","Oxytocin":"https://ionpeptide.com/product/oxy/","PDA":"https://ionpeptide.com/product/pda10/","PE-22-28":"https://ionpeptide.com/product/pe222810/","PEG-MGF":"https://ionpeptide.com/product/pegmgf2/","Pinealon":"https://ionpeptide.com/product/pin10/","PNC-27":"https://ionpeptide.com/product/pnc10/","Retatrutide":"https://ionpeptide.com/product/ion3r/","Tirzepatide":"https://ionpeptide.com/product/ion2t/","Semaglutide":"https://ionpeptide.com/product/ion1s/","Bremelanotide":"https://ionpeptide.com/product/pt10/","Selank":"https://ionpeptide.com/product/slk/","Selank (N-Acetyl)":"https://ionpeptide.com/product/slna10/","Semax (N-Acetyl)":"https://ionpeptide.com/product/smxa/","Semax/Selank":"https://ionpeptide.com/product/smsk/","Sermorelin":"https://ionpeptide.com/product/smo/","Snap-8":"https://ionpeptide.com/product/sn810/","SS-31":"https://ionpeptide.com/product/2s31/","Tesa/Ipamo":"https://ionpeptide.com/product/tipa/","Tesamorelin":"https://ionpeptide.com/product/tesa/","Thymalin":"https://ionpeptide.com/product/thy10/","Thymosin alpha-1":"https://ionpeptide.com/product/ta1/","VIP":"https://ionpeptide.com/product/vip10/"};
function q(s){return encodeURIComponent(s)}
function category(n){if(/Retatrutide|Semaglutide|Tirzepatide|Liraglutide|Dulaglutide|Exenatide|Cagrilintide|Amycretin|Mazdutide|Pemvidutide|Survodutide|Eloralintide|Adipotide|AOD-9604|5-Amino-1MQ|AICAR|Tesofensine|L-Carnitine|Lipo-C/i.test(n))return'Weight loss & metabolic';if(/HGH|GHRP|CJC|Ipamorelin|Sermorelin|Hexarelin|IGF|MGF|Follistatin|ACE-031|Ibutamoren|Tesa\/Ipamo/i.test(n))return'Muscle, GH & performance';if(/BPC-157|TB-500|Thymosin beta-4|GHK-Cu|PDRN|KPV|LL-37|Glutathione/i.test(n))return'Recovery, repair & inflammation';if(/Semax|Selank|Dihexa|DSIP|Cerebrolysin|Cerebro Protein|P21|PE-22-28|Adamax|Oxytocin/i.test(n))return'Brain, mood & sleep';if(/MOTS-c|SS-31|Humanin|Epitalon|FOXO4-DRI|NAD\+|Methylene blue/i.test(n))return'Longevity & mitochondrial';if(/Thymosin alpha-1|VIP|Cibinetide/i.test(n))return'Immune & systemic signaling';if(/HCG|HMG|Gonadorelin|Kisspeptin|Testosterone|Bremelanotide/i.test(n))return'Hormones, fertility & sexual health';if(/Afamelanotide|Melanotan|AHK-Cu|GHK Complex|Matrixyl|Snap-8|PDRN Collagen|Centella/i.test(n))return'Skin, hair & cosmetic';if(/Bronchogen|Cardiogen|Cartalax|Chonluten|Crystagen|Ovagen|Pinealon|Vesugen|Vilon|Thymalin/i.test(n))return'Bioregulators & organ support';return'Other research compounds'}

const peptideDosagesAliases={
 "Bremelanotide":"PT-141",
 "CJC-1295 no DAC":"CJC-1295 NO DAC",
 "CJC-1295 with DAC":"CJC-1295 DAC",
 "CJC-1295 no DAC / Ipamorelin":"CJC-1295 NO DAC Ipamorelin",
 "Tesa/Ipamo":"Tesamorelin Ipamorelin",
 "Thymosin alpha-1":"Thymosin Alpha-1",
 "MOTS-c":"MOTS-C",
 "PEG-MGF":"PEG MGF",
 "Snap-8":"SNAP-8",
 "HGH":"HGH 191AA"
};
function peptideDosagesURL(n){
 const term=peptideDosagesAliases[n]||n;
 return 'https://peptidedosages.com/?s='+encodeURIComponent(term);
}
function dosageReferenceCard(n){
 const url=peptideDosagesURL(n);
 return `<article class="card">
   <div class="section-title">Dosage & Reconstitution Reference</div>
   <p class="copy">Open PeptideDosages for vial-strength charts, concentration math, syringe-unit conversions and research-protocol context for ${esc(n)} when available.</p>
   <div class="coa-help">External reference. Verify the compound, vial strength and source citations on the destination page. Research protocols are not individualized medical instructions.</div>
   <div class="source-row">
     <a class="source" target="_blank" rel="noopener" href="${url}">View Dosage Reference</a>
     <a class="source" target="_blank" rel="noopener" href="https://peptidedosages.com/dosages/">Browse All Protocols</a>
   </div>
 </article>`;
}

function render(n){const [label,cls]=status(n);document.getElementById('compoundLabel').textContent=n;document.getElementById('profile').innerHTML=`<article class="card"><div class="profile-head"><div><div class="sect">Selected compound</div><h2>${n}</h2></div><span class="badge ${cls}">${label}</span></div></article><article class="card"><div class="section-title">Usage</div><p class="copy">${uses[n]||fallback(n)}</p></article><article class="card"><div class="section-title">Dosing • Reddit reports</div><p class="copy">${community(n)}</p></article><article class="card"><div class="section-title">Evidence snapshot</div><p class="copy">${evidence(n)}</p></article><article class="card"><div class="section-title">Things to watch</div><ul class="copy">${safety(n).map(x=>`<li>${x}</li>`).join('')}</ul></article>${dosageReferenceCard(n)}<article class="card"><div class="section-title">Research links</div><div class="source-row"><a class="source" target="_blank" rel="noopener" href="https://www.reddit.com/search/?q=${q(n)}">Reddit</a><a class="source" target="_blank" rel="noopener" href="https://pubmed.ncbi.nlm.nih.gov/?term=${q(n)}">PubMed</a>${ionLinks[n]?`<a class="source" target="_blank" rel="noopener" href="${ionLinks[n]}">ION Peptide</a>`:`<span class="source source-disabled" aria-disabled="true">ION • Not listed</span>`}</div></article>`;localStorage.setItem('research:last',n)}
const sheet=document.getElementById('compoundSheet'),opts=document.getElementById('pickerOptions'),search=document.getElementById('compoundSearch');function draw(filter=''){const f=filter.trim().toLowerCase(),current=document.getElementById('compoundLabel').textContent;const list=compounds.filter(x=>x.toLowerCase().includes(f));if(f){opts.innerHTML=`<div class="picker-group">Search results · ${list.length}</div>`+list.map(n=>{const [lab,cls]=status(n);return`<button class="picker-option ${current===n?'active':''}" data-name="${n}"><span>${n}</span><span class="badge ${cls}">${lab}</span></button>`}).join('')}else{const order=['Weight loss & metabolic','Muscle, GH & performance','Recovery, repair & inflammation','Brain, mood & sleep','Longevity & mitochondrial','Immune & systemic signaling','Hormones, fertility & sexual health','Skin, hair & cosmetic','Bioregulators & organ support','Other research compounds'];opts.innerHTML=order.map(cat=>{const group=list.filter(n=>category(n)===cat);if(!group.length)return'';return`<div class="picker-group">${cat} · ${group.length}</div>`+group.map(n=>{const [lab,cls]=status(n);return`<button class="picker-option ${current===n?'active':''}" data-name="${n}"><span>${n}</span><span class="badge ${cls}">${lab}</span></button>`}).join('')}).join('')}opts.querySelectorAll('[data-name]').forEach(b=>b.onclick=()=>{render(b.dataset.name);close()})}function openCompoundPicker(){draw();search.value='';sheet.hidden=false;document.body.classList.add('picker-open');setTimeout(()=>search.focus(),50)}function close(){sheet.hidden=true;document.body.classList.remove('picker-open')}document.getElementById('compoundButton').onclick=openCompoundPicker;document.getElementById('pickerBackdrop').onclick=close;document.getElementById('pickerClose').onclick=close;search.oninput=e=>draw(e.target.value);document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
const researchTab=document.getElementById('researchTab'),coaTab=document.getElementById('coaTab'),researchView=document.getElementById('researchView'),coaView=document.getElementById('coaView');
function setMode(mode){const c=mode==='coa';researchView.hidden=c;coaView.hidden=!c;researchTab.classList.toggle('active',!c);coaTab.classList.toggle('active',c);localStorage.setItem('research:mode',mode)}
researchTab.onclick=()=>setMode('research');coaTab.onclick=()=>setMode('coa');

function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const coaSearchBtn=document.getElementById('coaSearchBtn');
const coaQuery=document.getElementById('coaQuery');
const coaResults=document.getElementById('coaResults');
const coaImage=document.getElementById('coaImage');
const coaPreview=document.getElementById('coaPreview');
const coaPreviewWrap=document.getElementById('coaPreviewWrap');
const coaPdfPreview=document.getElementById('coaPdfPreview');
const coaPdfName=document.getElementById('coaPdfName');
const coaAnalyzeBtn=document.getElementById('coaAnalyzeBtn');
let coaImageURL='';

const coaLabs=[
 {id:'janoshik',name:'Janoshik',patterns:[/JANOSHIK/i,/JANOSHIK\.COM/i],url:'https://janoshik.com/verification/',note:'Official verification uses a Task number and Unique key.'},
 {id:'freedom',name:'Freedom Diagnostics',patterns:[/FREEDOM\s+DIAGNOSTICS/i,/FREEDOMDIAGNOSTICSTESTING/i],url:'https://freedomdiagnosticstesting.com/search-for-your-coa-based-on-the-unique-accession-number/',note:'Official lookup supports Search Code, accession number or company.'},
 {id:'vanguard',name:'Vanguard Laboratory',patterns:[/VANGUARD\s+LAB/i,/VERIFIED\s+BY\s+VANGUARD/i,/VERIFIEDBYVANGUARD/i],url:'https://verifiedbyvanguard.com/',note:'Official reporting hub can look up a Report # or COA #.'},
 {id:'ils',name:'ILS Laboratories',patterns:[/ILS\s+LAB/i,/ILS-LAB\.COM/i,/ILS\s+LABORATOR/i],url:'https://ils-lab.com/verify/',note:'Official verification uses the access code printed by the QR code.'},
 {id:'horizon',name:'Horizon Analytical',patterns:[/HORIZON\s+ANALYTICAL/i,/HORIZONANALYTICAL/i],url:'https://horizonanalytical.com/verify-coa',note:'Official public certificate lookup.'},
 {id:'bioregen',name:'BioRegen',patterns:[/BIOREGEN/i,/BIOREGEN\.COM/i],url:'https://bioregen.com/report/',note:'Official report search; BioRegen COAs may show a COA # and Security Key.'},
 {id:'trustpointe',name:'TrustPointe Analytics',patterns:[/TRUSTPOINTE/i,/TRUSTPOINTE\s+ANALYTICS/i,/TRUSTPOINTELIMS/i],url:'https://trustpointelims.com/',note:'Official LIMS verification uses the key or QR code on the COA.'},
 {id:'chromate',name:'Chromate',patterns:[/CHROMATE/i,/CHROMATE\.ORG/i],url:'https://chromate.org/verify',note:'Official verification-code portal.'}
];

function labFromText(text){const hits=coaLabs.filter(l=>l.patterns.some(p=>p.test(text)));return hits[0]||null}
function cleanId(x){return(x||'').replace(/[|,;]+$/,'').trim()}
function firstMatch(text,patterns){for(const p of patterns){const m=text.match(p);if(m&&m[1])return cleanId(m[1])}return''}
function extractCOAFields(text){
 const upper=text.toUpperCase();
 const lot=firstMatch(upper,[/(?:LOT|LOT\s*NUMBER|BATCH|BATCH\s*NUMBER|BATCH\s*NO\.?)[\s:#-]+([A-Z0-9][A-Z0-9._\/-]{2,35})/i]);
 const report=firstMatch(upper,[/(?:REPORT|REPORT\s*NO\.?|REPORT\s*NUMBER|COA|COA\s*NO\.?|COA\s*NUMBER|ACCESSION|ACCESSION\s*NUMBER)[\s:#-]+([A-Z0-9][A-Z0-9._\/-]{2,40})/i]);
 const searchCode=firstMatch(text,[/(?:SEARCH\s*CODE)[\s:#-]+([A-Z0-9][A-Z0-9._\/-]{3,50})/i]);
 const access=firstMatch(upper,[/(?:ACCESS\s*CODE|VERIFICATION\s*CODE|SECURITY\s*KEY|UNIQUE\s*KEY|VERIFY\s*KEY|KEY)[\s:#-]+([A-Z0-9][A-Z0-9._\/-]{3,40})/i]);
 const task=firstMatch(upper,[/(?:TASK|TASK\s*NUMBER|TASK\s*NO\.?)[\s:#-]+(\d{4,10})/i]);
 return{lot,report,searchCode,access,task};
}

function cleanOCRValue(v){
 return (v||'').replace(/\s{2,}/g,' ').replace(/^[\s:;#-]+|[\s|]+$/g,'').trim();
}
function lineValue(text,labels){
 const lines=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 for(const line of lines){
  for(const label of labels){
   const m=line.match(new RegExp('^'+label+'\\s*[:#-]?\\s*(.+)$','i'));
   if(m&&m[1])return cleanOCRValue(m[1]);
  }
 }
 return'';
}
function nearbyResult(text,labels){
 const lines=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 for(let i=0;i<lines.length;i++){
  if(labels.some(r=>r.test(lines[i]))){
   const chunk=[lines[i],lines[i+1]||'',lines[i+2]||''].join(' ');
   const explicit=chunk.match(/\b(PASS(?:ED)?|COMPLIANT|CONFORMS?|NEGATIVE|NOT DETECTED|ND|FAIL(?:ED)?|NON[- ]?COMPLIANT|POSITIVE)\b/i);
   const value=chunk.match(/(?:<|>|≤|≥)?\s*\d+(?:\.\d+)?\s*(?:%|EU\/MG|EU\/ML|CFU\/G|CFU\/ML|MG|MCG|NG\/G|PPM|PPB)\b/i);
   if(explicit)return cleanOCRValue(explicit[0]);
   if(value)return cleanOCRValue(value[0]);
   return cleanOCRValue(lines[i].replace(/^.*?(?:[:\-])\s*/,''));
  }
 }
 return'';
}
function extractCOASummary(text,lab,fields){
 const product=lineValue(text,['PRODUCT(?: NAME)?','COMPOUND','PEPTIDE','SAMPLE(?: NAME)?']);
 const vendor=lineValue(text,['CLIENT(?: NAME)?','VENDOR','COMPANY','CUSTOMER']);
 const testDate=lineValue(text,['DATE REPORTED','REPORT DATE','TEST DATE','DATE TESTED','DATE OF ANALYSIS','ANALYSIS DATE']);
 const purity=lineValue(text,['PURITY(?: BY HPLC)?','HPLC PURITY','PURITY RESULT']) ||
   ((String(text).match(/\b(?:PURITY|HPLC)\b[^\n]{0,45}?(\d{2,3}(?:\.\d+)?)\s*%/i)||[])[1] ? ((String(text).match(/\b(?:PURITY|HPLC)\b[^\n]{0,45}?(\d{2,3}(?:\.\d+)?)\s*%/i)||[])[1]+'%') : '');
 const quantity=lineValue(text,['NET PEPTIDE CONTENT','PEPTIDE CONTENT','NET CONTENT','QUANTITY','MASS']);
 const identity=lineValue(text,['IDENTITY(?: RESULT)?','IDENTIFICATION']) || nearbyResult(text,[/\bIDENTITY\b/i,/\bMASS\s+SPEC(?:TROMETRY)?\b/i]);
 const sterility=nearbyResult(text,[/\bSTERILITY\b/i]);
 const endotoxin=nearbyResult(text,[/\bENDOTOXIN\b/i,/\bLAL\b/i]);
 const heavyMetals=nearbyResult(text,[/\bHEAVY\s+METALS?\b/i,/\bICP[- ]?MS\b/i]);
 const microbial=nearbyResult(text,[/\bMICROBIAL\b/i,/\bMICROBIOLOG(?:Y|ICAL)\b/i,/\bTOTAL\s+PLATE\s+COUNT\b/i]);
 return{
  product,vendor,lab:lab?.name||'',lot:fields?.lot||'',report:fields?.searchCode||fields?.report||fields?.task||'',
  testDate,purity,quantity,identity,sterility,endotoxin,heavyMetals,microbial
 };
}
function resultTone(value){
 const v=String(value||'').toUpperCase();
 if(!v)return'missing';
 if(/\b(FAIL|FAILED|NON[- ]?COMPLIANT|POSITIVE)\b/.test(v))return'fail';
 if(/\b(PASS|PASSED|COMPLIANT|CONFORM|NEGATIVE|NOT DETECTED|ND)\b/.test(v))return'pass';
 return'info';
}
function summaryCell(label,value,{test=false}={}){
 const shown=value||'Not listed / not read';
 const tone=value?(test?resultTone(value):'info'):'missing';
 return `<div class="coa-summary-cell ${tone}"><span>${label}</span><strong>${esc(shown)}</strong></div>`;
}
function renderCOASummary(summary){
 const tested=[
  ['Identity',summary.identity],
  ['Sterility',summary.sterility],
  ['Endotoxin',summary.endotoxin],
  ['Heavy metals',summary.heavyMetals],
  ['Microbial',summary.microbial]
 ];
 const explicitFail=tested.some(([,v])=>resultTone(v)==='fail');
 const explicitPass=tested.some(([,v])=>resultTone(v)==='pass');
 const badge=explicitFail?['Review result','fail']:explicitPass?['Results detected','pass']:['OCR summary','info'];
 return `<article class="card coa-summary-card">
   <div class="coa-summary-head">
     <div><div class="section-title">COA Results Summary</div><h3>${esc(summary.product||'Certificate analysis')}</h3></div>
     <span class="coa-summary-badge ${badge[1]}">${badge[0]}</span>
   </div>
   <div class="coa-summary-grid">
     ${summaryCell('Vendor / company',summary.vendor)}
     ${summaryCell('Testing lab',summary.lab)}
     ${summaryCell('Lot / batch',summary.lot)}
     ${summaryCell('Report / search code',summary.report)}
     ${summaryCell('Test date',summary.testDate)}
     ${summaryCell('Purity',summary.purity)}
     ${summaryCell('Net peptide content',summary.quantity)}
     ${summaryCell('Identity',summary.identity,{test:true})}
     ${summaryCell('Sterility',summary.sterility,{test:true})}
     ${summaryCell('Endotoxin',summary.endotoxin,{test:true})}
     ${summaryCell('Heavy metals',summary.heavyMetals,{test:true})}
     ${summaryCell('Microbial',summary.microbial,{test:true})}
   </div>
   <div class="coa-summary-note">“Not listed / not read” means the OCR did not find that result. It does not mean the sample failed that test. Confirm all values against the original COA.</div>
 </article>`;
}

function qrOfficial(url){try{const u=new URL(url);return /janoshik\.com|freedomdiagnosticstesting\.com|verifiedbyvanguard\.com|ils-lab\.com|horizonanalytical\.com|bioregen\.com|trustpointelims\.com|trustpointeanalytics\.com|chromate\.org|disclosedlabs\.com/i.test(u.hostname)}catch{return false}}

function disclosedLotURL(lot){return'https://www.disclosedlabs.com/lot/'+encodeURIComponent(lot)}
function genericSearchURL(raw){return'https://www.google.com/search?q='+encodeURIComponent('"'+raw+'" COA peptide')}
function fieldRows(f){return[['Lot / batch',f.lot],['Search Code',f.searchCode],['Report / COA / accession',f.report],['Task number',f.task],['Access / unique / security key',f.access]].filter(x=>x[1]).map(x=>`<div class="coa-field"><span>${x[0]}</span><strong>${esc(x[1])}</strong></div>`).join('')}
function resultCard(lab,fields,qrUrl,textNote=''){
 const best=fields.searchCode||fields.lot||fields.report||fields.access||fields.task||'';
 const links=[];
 if(qrUrl&&qrOfficial(qrUrl))links.push({label:'Open QR Verification',url:qrUrl});
 if(lab&&lab.id!=='freedom')links.push({label:`Verify at ${lab.name}`,url:lab.url});
 if(lab&&lab.id==='freedom'){
   const freedomCode=fields.searchCode||fields.report||fields.lot||'';
   if(freedomCode){
     links.push({label:'Confirm Search Code & Open Freedom',url:'#',action:`freedom-confirm:${encodeURIComponent(freedomCode)}`});
   }else links.push({label:'Open Freedom Diagnostics',url:lab.url});
 }
 if(fields.lot)links.push({label:'Search Lot on Disclosed Labs',url:disclosedLotURL(fields.lot)});
 if(best)links.push({label:'Broad Exact COA Search',url:genericSearchURL(best)});
 return`<article class="card"><div class="coa-result-title"><strong>${lab?'Likely lab: '+esc(lab.name):'Lab not confidently identified'}</strong><span class="coa-status">${lab?'Detected':'Review'}</span></div>${textNote?`<p class="copy">${textNote}</p>`:''}<div class="coa-fields">${fieldRows(fields)||'<div class="coa-empty">No labeled identifiers were read clearly. Try a sharper screenshot or use manual search.</div>'}</div><div class="coa-actions">${links.map(x=>x.action?`<button class="coa-link coa-action-btn" type="button" data-coa-action="${x.action}">${x.label}</button>`:`<a class="coa-link" target="_blank" rel="noopener" href="${x.url}">${x.label}</a>`).join('')}</div>${lab?`<div class="coa-help">${lab.note}</div>`:'<div class="coa-help">Use the source buttons below or manually enter the clearest lot/report number you can read.</div>'}</article>`;
}

function freedomConfirmCard(code){
 const safe=esc(code||'');
 return `<article class="card" id="freedomConfirmCard">
   <div class="section-title">Confirm Freedom Search Code</div>
   <p class="copy">OCR can confuse characters such as <strong>I / 1</strong> and <strong>O / 0</strong>. Check the code against the COA before copying it.</p>
   <label class="coa-confirm-label" for="freedomCodeInput">Detected Search Code</label>
   <input class="control coa-confirm-input" id="freedomCodeInput" value="${safe}" autocomplete="off" autocapitalize="characters" spellcheck="false">
   <div class="coa-help">Edit any incorrect character, then continue.</div>
   <button class="coa-search-btn" type="button" data-coa-action="freedom-open-confirmed">Copy Confirmed Code & Open Freedom</button>
 </article>`;
}

function unknownLabButtons(){return`<article class="card"><div class="section-title">Official verification sites</div><div class="coa-actions">${coaLabs.map(l=>`<a class="coa-link" target="_blank" rel="noopener" href="${l.url}">${l.name}</a>`).join('')}<a class="coa-link" target="_blank" rel="noopener" href="https://www.disclosedlabs.com/coas">Disclosed Labs COA Index</a></div></article>`}

function manualCOASearch(){
 const raw=(coaQuery?.value||'').trim();
 if(!raw){coaResults.innerHTML='<article class="card"><div class="coa-empty">Enter a lot, batch, COA, report, task or access code first.</div></article>';coaQuery?.focus();return}
 const fields=extractCOAFields(raw.includes(':')?raw:'LOT: '+raw);
 const lab=labFromText(raw);
 if(!fields.lot&&!fields.report&&!fields.access&&!fields.task)fields.lot=raw;
 coaResults.innerHTML=resultCard(lab,fields,'','Use the detected identifier to search the broad COA index or open an official laboratory verifier.')+unknownLabButtons();
 coaResults.scrollIntoView({behavior:'smooth',block:'start'});
}


async function handleCOAAction(e){
 const btn=e.target.closest('[data-coa-action]');if(!btn)return;
 e.preventDefault();
 e.stopPropagation();
 const action=btn.dataset.coaAction||'';
 const freedomURL='https://freedomdiagnosticstesting.com/search-for-your-coa-based-on-the-unique-accession-number/';

 if(action.startsWith('freedom-confirm:')){
   const code=decodeURIComponent(action.slice('freedom-confirm:'.length));
   const existing=document.getElementById('freedomConfirmCard');
   if(existing)existing.remove();
   btn.closest('.card')?.insertAdjacentHTML('afterend',freedomConfirmCard(code));
   const input=document.getElementById('freedomCodeInput');
   if(input){
     input.focus();
     input.setSelectionRange(input.value.length,input.value.length);
   }
   document.getElementById('freedomConfirmCard')?.scrollIntoView({behavior:'smooth',block:'center'});
   return;
 }

 if(action==='freedom-open-confirmed'){
   const input=document.getElementById('freedomCodeInput');
   const code=(input?.value||'').trim();
   if(!code){
     if(input){input.focus();input.placeholder='Enter the Search Code';}
     return;
   }

   const tab=window.open(freedomURL,'_blank','noopener');
   try{
     await navigator.clipboard.writeText(code);
     btn.textContent='Search Code copied ✓';
   }catch{
     btn.textContent='Freedom opened • copy: '+code;
   }
   if(!tab)window.location.href=freedomURL;
   return;
 }
}
if(coaResults)coaResults.addEventListener('click',handleCOAAction);

async function detectQR(file){
 if(!('BarcodeDetector'in window))return'';
 try{const d=new BarcodeDetector({formats:['qr_code']});const bmp=await createImageBitmap(file);const codes=await d.detect(bmp);bmp.close();return codes[0]?.rawValue||''}catch{return''}
}

function isPDFFile(file){
 return !!file && (file.type==='application/pdf' || /\.pdf$/i.test(file.name||''));
}
async function loadPDFDocument(file){
 if(!window.pdfjsLib)throw new Error('PDF reader unavailable');
 pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js';
 const data=await file.arrayBuffer();
 return await pdfjsLib.getDocument({data}).promise;
}
async function extractPDFText(pdf){
 let text='';
 const maxPages=Math.min(pdf.numPages,12);
 for(let pageNo=1;pageNo<=maxPages;pageNo++){
  const p=document.getElementById('coaProgress');
  if(p)p.textContent=`Reading PDF text… page ${pageNo} of ${maxPages}`;
  const page=await pdf.getPage(pageNo);
  const content=await page.getTextContent();
  text += '\n' + content.items.map(i=>i.str).join(' ');
 }
 return text.trim();
}
async function renderPDFPage(page,scale=1.65){
 const viewport=page.getViewport({scale});
 const canvas=document.createElement('canvas');
 const ctx=canvas.getContext('2d',{willReadFrequently:true});
 canvas.width=Math.ceil(viewport.width);
 canvas.height=Math.ceil(viewport.height);
 await page.render({canvasContext:ctx,viewport}).promise;
 return canvas;
}
async function ocrPDFPages(pdf){
 if(!window.Tesseract)throw new Error('OCR library unavailable');
 let text='';
 const maxPages=Math.min(pdf.numPages,4);
 for(let pageNo=1;pageNo<=maxPages;pageNo++){
  const page=await pdf.getPage(pageNo);
  const canvas=await renderPDFPage(page);
  const res=await Tesseract.recognize(canvas,'eng',{logger:m=>{
   const p=document.getElementById('coaProgress');
   if(p&&m.status==='recognizing text')p.textContent=`Reading scanned PDF… page ${pageNo} of ${maxPages} · ${Math.round((m.progress||0)*100)}%`;
  }});
  text += '\n' + (res?.data?.text||'');
 }
 return text.trim();
}
async function detectQRFromPDF(pdf){
 if(!('BarcodeDetector' in window))return'';
 try{
  const page=await pdf.getPage(1);
  const canvas=await renderPDFPage(page,1.5);
  const d=new BarcodeDetector({formats:['qr_code']});
  const codes=await d.detect(canvas);
  return codes[0]?.rawValue||'';
 }catch{return''}
}

async function analyzeCOAImage(){
 const file=coaImage?.files?.[0];if(!file)return;
 coaAnalyzeBtn.disabled=true;coaAnalyzeBtn.textContent='Reading COA…';
 const pdfMode=isPDFFile(file);
 coaResults.innerHTML=`<article class="card"><div class="coa-result-title"><strong>Reading ${pdfMode?'PDF':'COA image'}</strong><span class="coa-status">${pdfMode?'PDF':'OCR'}</span></div><p class="copy" id="coaProgress">Looking for lab name, lot/batch, report number, verification code and test results…</p></article>`;
 try{
  let text='',qr='';
  if(pdfMode){
   const pdf=await loadPDFDocument(file);
   text=await extractPDFText(pdf);
   qr=await detectQRFromPDF(pdf);
   if(text.replace(/\s+/g,' ').trim().length<80){
    const p=document.getElementById('coaProgress');
    if(p)p.textContent='This looks like a scanned PDF. Switching to OCR…';
    text=await ocrPDFPages(pdf);
   }
  }else{
   const qrPromise=detectQR(file);
   if(!window.Tesseract)throw new Error('OCR library unavailable');
   const res=await Tesseract.recognize(file,'eng',{logger:m=>{
    const p=document.getElementById('coaProgress');
    if(p&&m.status==='recognizing text')p.textContent='Reading text… '+Math.round((m.progress||0)*100)+'%';
   }});
   text=res?.data?.text||'';
   qr=await qrPromise;
  }

  const lab=labFromText(text+' '+qr);
  const fields=extractCOAFields(text);
  if(lab?.id==='janoshik'){
   if(!fields.task)fields.task=firstMatch(text,[/(?:TASK|TASK\s*NUMBER|TASK\s*NO\.?)[\s:#-]+(\d{4,10})/i]);
   if(!fields.access)fields.access=firstMatch(text,[/(?:UNIQUE\s*KEY|KEY)[\s:#-]+([A-Z0-9]{8,24})/i]);
  }
  if(lab?.id==='ils'&&!fields.access)fields.access=firstMatch(text,[/(?:ACCESS\s*CODE)[\s:#-]+([A-Z0-9]{6,12})/i]);
  if(lab?.id==='bioregen'&&!fields.access)fields.access=firstMatch(text,[/(?:SECURITY\s*KEY)[\s:#-]+([A-Z0-9]{6,30})/i]);

  const summary=extractCOASummary(text,lab,fields);
  coaResults.innerHTML=renderCOASummary(summary)+resultCard(
   lab,fields,qr,
   lab
    ?`The ${pdfMode?'PDF':'image'} appears to match this laboratory. Confirm the details on the official site before treating it as verified.`
    :`I could not confidently identify the laboratory from this ${pdfMode?'PDF':'image'}.`
  )+(!lab?unknownLabButtons():'');
  coaResults.scrollIntoView({behavior:'smooth',block:'start'});
 }catch(err){
  console.error(err);
  coaResults.innerHTML='<article class="card"><div class="coa-empty">I could not read this COA in the browser. Try a clearer image/PDF, or enter the lot/report number manually below.</div></article>'+unknownLabButtons();
 }finally{
  coaAnalyzeBtn.disabled=false;
  coaAnalyzeBtn.textContent='Read & Identify COA';
 }
}
if(coaImage)coaImage.addEventListener('change',()=>{const f=coaImage.files?.[0];if(!f)return;if(coaImageURL)URL.revokeObjectURL(coaImageURL);coaImageURL='';coaPreviewWrap.hidden=false;coaResults.innerHTML='';if(isPDFFile(f)){coaPreview.hidden=true;if(coaPdfPreview)coaPdfPreview.hidden=false;if(coaPdfName)coaPdfName.textContent=f.name||'COA PDF';}else{if(coaPdfPreview)coaPdfPreview.hidden=true;coaPreview.hidden=false;coaImageURL=URL.createObjectURL(f);coaPreview.src=coaImageURL;}});
if(coaAnalyzeBtn)coaAnalyzeBtn.addEventListener('click',analyzeCOAImage);
if(coaSearchBtn)coaSearchBtn.addEventListener('click',manualCOASearch);
if(coaQuery)coaQuery.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();manualCOASearch()}});

setMode(localStorage.getItem('research:mode')==='coa'?'coa':'research');

render(compounds.includes(localStorage.getItem('research:last'))?localStorage.getItem('research:last'):'Retatrutide');
